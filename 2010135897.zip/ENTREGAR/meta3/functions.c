#include "functions.h"
#include "structures.h"
#include <stdlib.h>
#include <stdio.h>
#include "shows.h"

program_tree* insert_list_root(program_tree* head)
{
	program_tree* node=(program_tree*)malloc(sizeof(program_tree));	//Cria novo nó na lista	
	node->val = NULL;
	node->disc_d = Program;	
	node->son=head;
	node->brother=NULL;	//Preenche-o
			//adiciona no final da lista
	
	return node;
}

program_tree* insert_id(char* id)
{
	/*printf("id %s\n",id);*/
	program_tree* node=(program_tree*)malloc(sizeof(program_tree));	//Cria novo nó na lista	
	node->val = id;
	node->disc_d = Id;	
	node->son=NULL;
	node->brother=NULL;	//Preenche-o
			//adiciona no final da lista
	
	return node;
}



program_tree* insert_type(int type)
{
	program_tree* node=(program_tree*)malloc(sizeof(program_tree));	//Cria novo nó na lista	
	node->val = NULL;
	switch(type)
	{
		case 1: node->disc_d = Int;break;
		case 2: node->disc_d = Bool;break;
		case 3: node->disc_d = IntArray;break;
		case 4: node->disc_d = BoolArray;break;
		case 5: node->disc_d = Void;break;
		case 6: node->disc_d = StringArray;break;
	}
	node->son=NULL;
	node->brother=NULL;	

	
	return node;
}

program_tree* insert_vardecl(program_tree* type_node, program_tree* id_node)
{
	program_tree* node=(program_tree*)malloc(sizeof(program_tree));	//Cria novo nó na lista	
	node->val = NULL;
	node->brother=NULL;	

	node->disc_d = VarDecl;

	type_node->brother = id_node;
	/*printf("insert_vardeclID %s\n", id_node->val);*/

	node->son=type_node;
	
	
	return node;
}


program_tree* insert_program(program_tree* id_node, program_tree* fmdecl_node)
{
	program_tree* node=(program_tree*)malloc(sizeof(program_tree));	//Cria novo nó na lista	
	program_tree* nullnode;
	node->val = NULL;

	node->disc_d = Program;	

	if(id_node!=NULL){
		node->son=id_node;
		id_node->brother = fmdecl_node;
		node->brother=NULL;	
	}
	else
	{
		nullnode = insert_nullnode();
		node->son=nullnode;
		node->brother=NULL;
	}

	
	return node;

}

program_tree* insert_nullnode()
{
	program_tree* node=(program_tree*)malloc(sizeof(program_tree));
	node->val=NULL;
	node->disc_d = Null;
	node->son = NULL;
	node->brother=NULL;
}

program_tree* insert_methoddecl(program_tree* type_node, program_tree* id_node, program_tree* methodparams_node, program_tree* methodbody_node)
{
	program_tree* node=(program_tree*)malloc(sizeof(program_tree));	//Cria novo nó na lista	
	node->val = NULL;
	node->brother=NULL;	

	node->disc_d = MethodDecl;

	type_node->brother = id_node;
	id_node->brother = methodparams_node;
	methodparams_node->brother = methodbody_node;

	node->son=type_node;
	
	
	return node;
}

program_tree* insert_methodparams(program_tree* paramdeclaration_node)
{

	/*printf("insert_methodparams \n");*/
	program_tree* node=(program_tree*)malloc(sizeof(program_tree));	//Cria novo nó na lista	
	node->val = NULL;
	node->brother=NULL;	

	node->disc_d = MethodParams;


	node->son=paramdeclaration_node;


	
	
	return node;
}

program_tree* insert_brother(program_tree* top_node, program_tree* node_to_insert)
{
	program_tree* node;	//Cria novo nó na lista	
	/*printf("brotherfunc\n");*/
	/*show_disc(top_node->disc_d);*/
	/*show_disc(node_to_insert->disc_d);*/

	for(node=top_node; node!=NULL ; node=node->brother)
	{	
		if(node->brother==NULL)
		{	/*printf("brother %s %s\n",node->son->brother->val,node_to_insert->son->brother->val);*/
			node->brother=node_to_insert;
			break;
		}
	}

}

program_tree* insert_son(program_tree* top_node, program_tree* node_to_insert)
{
	program_tree* node;	//Cria novo nó na lista	
	/*printf("sonfunc\n");*/
	/*switch(top_node->disc_d)
	{
		case VarDecl: printf("VarDecl\n");break;
		default: printf("asdasd\n");
	}*/
/*
	switch(top_node->son->disc_d)
	{
		case Int: printf("Int\n");break;
		default:printf("asd\n");
	}*/
		/*if(top_node!=NULL && node_to_insert!=NULL)
		printf("son %s %s\n", top_node->son->brother->val,node_to_insert->son->brother->val);*/

	for(node=top_node->son; node!=NULL ; node=node->brother)
	{
		if(node->brother==NULL)
		{	/*printf("son2\n");*/
			node->brother=node_to_insert;
			break;
		}
	}

	return top_node;

}

program_tree* insert_formalparams(program_tree* type_node, program_tree* id_node)
{
	program_tree* node=(program_tree*)malloc(sizeof(program_tree));	//Cria novo nó na lista	
	node->val = NULL;
	node->brother=NULL;	

	node->disc_d = ParamDeclaration;

	type_node->brother = id_node;

	node->son=type_node;
	
	
	return node;
}

program_tree* insert_call(program_tree* id_node, program_tree* args_node)
{
	program_tree* node=(program_tree*)malloc(sizeof(program_tree));	//Cria novo nó na lista	
	node->val = NULL;
	node->brother=NULL;	

	node->disc_d = Call;

	node->son=id_node;

	id_node->brother=args_node;
	
	
	return node;
}

program_tree* insert_boollit(char* boollit)
{
		/*printf("BOOLLIT %s\n", boollit);*/
	program_tree* node=(program_tree*)malloc(sizeof(program_tree));	//Cria novo nó na lista	
	node->val = boollit;
	node->brother=NULL;	

	node->disc_d = BoolLit;

	node->son=NULL;
	
	
	return node;
}

program_tree* insert_intlit(char* intlit)
{
	/*printf("INTLIT %s\n", intlit);*/
	program_tree* node=(program_tree*)malloc(sizeof(program_tree));	//Cria novo nó na lista	
	node->val = intlit;
	node->brother=NULL;	


	node->disc_d = IntLit;

	node->son=NULL;
	
	
	return node;
}

program_tree* insert_return(program_tree *expr)
{
	program_tree* node=(program_tree*)malloc(sizeof(program_tree));	//Cria novo nó na lista	
	node->val = NULL;
	node->brother=NULL;	

	node->disc_d = Return;

	if(expr == NULL)
		node->son=NULL;
	else
		node->son=expr;
	
	
	return node;
}

program_tree* insert_methodbody(program_tree* vardecl_node, program_tree* statements_node)
{
	program_tree* node=(program_tree*)malloc(sizeof(program_tree));	//Cria novo nó na lista	
	program_tree*aux;
	node->val = NULL;
	node->brother=NULL;	

	node->disc_d = MethodBody;

	if(vardecl_node!=NULL)
	{

		aux=vardecl_node;
		while(aux->brother!=NULL)
			aux = aux->brother;

		

		node->son=vardecl_node;

		aux->brother = statements_node;

	}
	else
	{
		node->son=statements_node;
	}

	
	
	return node;
}

program_tree *insert_infix_expression(program_tree *op1, disc_expression oper, program_tree *op2)
{
        program_tree *iie=(program_tree*)malloc(sizeof(program_tree));
		iie->disc_d=oper;
		iie->val=NULL;

		iie->son=op1;
		op1->brother = op2;

        return iie;
}

program_tree* insert_unary_expression(disc_expression oper, program_tree* expression)
{
        program_tree *iue=(program_tree*)malloc(sizeof(program_tree));
        iue->disc_d = oper;
        iue->val = NULL;
        iue->son=expression;
        iue->brother=NULL;			

        return iue;
}

program_tree* insert_parseint(program_tree* id_node, program_tree* expression)
{
        program_tree *node=(program_tree*)malloc(sizeof(program_tree));
        node->disc_d = ParseArgs;
        node->val = NULL;
        node->son=id_node;
        node->brother=NULL;
        id_node->brother=expression;

        return node;
}


program_tree* insert_loadarray(program_tree* expr1, program_tree* expr2)
{
        program_tree *node=(program_tree*)malloc(sizeof(program_tree));
        node->disc_d = LoadArray;
        node->val = NULL;
        node->son=expr1;
        node->brother=NULL;
        expr1->brother=expr2;

        return node;
}

program_tree* insert_store(program_tree* id_node, program_tree* expr)
{
        program_tree *node=(program_tree*)malloc(sizeof(program_tree));
        node->disc_d = Store;
        node->val = NULL;
        node->son=id_node;
        node->brother=NULL;
        id_node->brother=expr;
        /*show_disc(id_node->disc_d);
        printf("\t");
        show_disc(expr->disc_d);
        printf("\t %s \n",expr->val);*/

        return node;
}

program_tree* insert_storearray(program_tree* id_node, program_tree* expr1, program_tree* expr2)
{
        program_tree *node=(program_tree*)malloc(sizeof(program_tree));
        node->disc_d = StoreArray;
        node->val = NULL;
        node->son=id_node;
        node->brother=NULL;
        id_node->brother=expr1;
        expr1->brother=expr2;

        return node;
}

program_tree* insert_print(program_tree* expr)
{
        program_tree *node=(program_tree*)malloc(sizeof(program_tree));
        node->disc_d = Print;
        node->val = NULL;
        node->son=expr;
        node->brother=NULL;

        return node;
}

program_tree* insert_while(program_tree* expr, program_tree* statement)
{
        program_tree *node=(program_tree*)malloc(sizeof(program_tree));
        node->disc_d = While;
        node->val = NULL;
        node->son=expr;
        node->brother=NULL;
        if(statement!=NULL)
        	expr->brother = statement;
        else
        {
        	program_tree* nullnode=insert_nullnode();
    		expr->brother=nullnode;
        }

        return node;
}

program_tree* insert_ifelse(program_tree* expr, program_tree* stat1, program_tree* stat2)
{

        program_tree *node=(program_tree*)malloc(sizeof(program_tree));
        program_tree *nullnode;
        program_tree *nullnode2;
        node->disc_d = IfElse;
        node->val = NULL;
        node->son=expr;
        node->brother=NULL;
        if(stat1!=NULL){
		    expr->brother=stat1;
		    stat1->brother=stat2;
    	}
    	else
    	{
    		nullnode=insert_nullnode();
    		expr->brother=nullnode;
		    nullnode->brother=stat2;
    	}

    	if(stat2 == NULL)
    	{
    		nullnode2=insert_nullnode();
		    expr->brother->brother=nullnode2;
    	}


        return node;
}

program_tree* insert_if(program_tree* expr, program_tree* statement)
{

        program_tree *node=(program_tree*)malloc(sizeof(program_tree));
        node->disc_d = If;
        node->val = NULL;
        node->son=expr;
        node->brother=NULL;
        expr->brother=statement;


        return node;
}

program_tree* insert_compoundstatement(program_tree* statement)
{
	if(statement->brother!=NULL){
        program_tree *node=(program_tree*)malloc(sizeof(program_tree));
        node->disc_d = CompoundStat;
        node->val = NULL;
        node->son=statement;
        node->brother=NULL;
        return node;
    }
    else
    {
    	return statement;
    }

        
}
