#include "symbol_table.h"
#include<malloc.h>
#include<string.h>
#include<stdio.h>

extern table_element* symtab;


//Insere um novo identificador na cauda de uma lista ligada de simbolo
table_element *insert_el(char *str, disc_expression t, int is_param, int title_type)
{

	table_element *newSymbol=(table_element*) malloc(sizeof(table_element));
	table_element *aux;
	table_element* previous;
	
	switch(t)
	{
		case Program: strcpy(newSymbol->name, str);newSymbol->type=t; newSymbol->is_param=is_param;break;
		case Int: strcpy(newSymbol->name, str);newSymbol->type=t; newSymbol->is_param=is_param;break;
		case Bool: strcpy(newSymbol->name, str);newSymbol->type=t; newSymbol->is_param=is_param;break;
		case IntArray: strcpy(newSymbol->name, str);newSymbol->type=t; newSymbol->is_param=is_param;break;
		case BoolArray: strcpy(newSymbol->name, str);newSymbol->type=t; newSymbol->is_param=is_param;break;
		case StringArray: strcpy(newSymbol->name, str);newSymbol->type=t; newSymbol->is_param=is_param;break;
		case Void: strcpy(newSymbol->name, str);newSymbol->type=t; newSymbol->is_param=is_param;break;
		default: 	strcpy(newSymbol->name, str);newSymbol->is_param=is_param;newSymbol->type=t;
	}

	switch(title_type)
	{
		case 0: sprintf(newSymbol->title,"===== Class %s Symbol Table =====",str);break;
		case -1: strcpy(newSymbol->title, "");break;
	}

	newSymbol->next=NULL;	

	if(symtab)	//Se table ja tem elementos
	{	//Procura cauda da lista e verifica se simbolo ja existe (NOTA: assume-se uma tabela de simbolos globais!)
		for(aux=symtab; aux && aux->name!=NULL; previous=aux, aux=aux->next)
			if(aux->type!=Program && strcmp(aux->name, str)==0)
				return NULL;
		previous->next=newSymbol;	//adiciona ao final da lista
	}
	else	//symtab tem um elemento -> o novo simbolo
		symtab=newSymbol;		
	
	return newSymbol; 
}

table_element *insert_el_method(char *str, disc_expression t)
{	

	table_element *newSymbol=(table_element*) malloc(sizeof(table_element));
	table_element *newSymbolStuff=(table_element*) malloc(sizeof(table_element));
	table_element *aux;
	table_element* previous;

	strcpy(newSymbol->name, str);
	newSymbol->is_param=0;
	newSymbol->type=MethodDecl;
	newSymbol->next=NULL;
	newSymbol->method_stuff=NULL;

	strcpy(newSymbolStuff->name, str);
	newSymbolStuff->type=t; 
	newSymbolStuff->is_param=0;
	newSymbolStuff->next=NULL;
	newSymbolStuff->method_stuff=NULL;
	sprintf(newSymbolStuff->title,"===== Method %s Symbol Table =====",str);
	newSymbol->method_stuff=newSymbolStuff;

	if(symtab)	//Se table ja tem elementos
	{	//Procura cauda da lista e verifica se simbolo ja existe (NOTA: assume-se uma tabela de simbolos globais!)
		for(aux=symtab; aux && aux->name!=NULL; previous=aux, aux=aux->next)
			if(aux->type!=Program && strcmp(aux->name, str)==0)
				return NULL;
		
		previous->next=newSymbol;	//adiciona ao final da lista
	}
	else	//symtab tem um elemento -> o novo simbolo
		symtab=newSymbol;		
	

	return newSymbol; 

}

table_element *insert_el_in_method(disc_expression t, char* str_var, char* str_method, int is_param)
{
	table_element *newSymbol=(table_element*) malloc(sizeof(table_element));
	table_element *aux, *aux2;
	table_element* previous;

	strcpy(newSymbol->name, str_var);
	newSymbol->type=t; 
	newSymbol->is_param=is_param;
	strcpy(newSymbol->title, "");

	newSymbol->next=NULL;
	newSymbol->method_stuff=NULL;	
	 /*colocar variavel no metodo*/
	if(symtab)	//Se table ja tem elementos
	{	//Procura cauda da lista e verifica se simbolo ja existe (NOTA: assume-se uma tabela de simbolos globais!)
		for(aux=symtab; aux && aux->name!=NULL; previous=aux, aux=aux->next)
			if(aux->type==MethodDecl && strcmp(aux->name, str_method)==0)
			{
				previous=aux->method_stuff;
				aux=aux->method_stuff->next;
				while(aux!=NULL){
					if(aux->name!=NULL)
					{
						if(strcmp(aux->name,str_var)==0){
							return NULL;
						}
					}
					previous=aux;
					aux=aux->next;
				}
				previous->next=newSymbol;
				break;
				

				
			}
	}
	return newSymbol;

}

void show_table()
{
	table_element *aux;
	table_element *aux2;
	for(aux=symtab; aux; aux=aux->next)
	{
		if(strcmp(aux->title,""))
		{
			printf("%s\n", aux->title);
		}
		else
		{
			printf("%s\t", aux->name);
			show_type(aux->type);
			if(aux->is_param)
				printf("\tparam");
			printf("\n");
		}
	}
	

	for(aux=symtab; aux; aux=aux->next)
	{

		if(aux->type == MethodDecl)
		{
			for(aux2=aux->method_stuff ; aux2 ; aux2=aux2->next)
			{
				if(strcmp(aux2->title,""))
				{
					printf("\n");
					printf("%s\n", aux2->title);
					printf("return\t");
					show_type(aux2->type);
					printf("\n");
				}
				else
				{
					printf("%s\t", aux2->name);
					show_type(aux2->type);
					if(aux2->is_param)
						printf("\tparam");
					printf("\n");
				}
			}
			
		}

		
	}


}

void show_type(disc_expression d)
{
	switch(d)
	{
		case Int: printf("int");break;
		case Bool: printf("boolean");break;
		case IntArray: printf("int[]");break;
		case BoolArray: printf("boolean[]");break;
		case Void: printf("void");break;
		case StringArray: printf("String[]");break;
		case MethodDecl: printf("method");break;
		/*case ParamDeclaration: printf("ParamDeclaration\t");break;
		case StringArray: printf("String[]\t");break;
		case MethodParams: printf("MethodParams\t");break;
		case Call: printf("Call\t");break;
		case BoolLit: printf("BoolLit\t");break;
		case IntLit: printf("IntLit");break;
		case Return: printf("Return\t");break;
		case MethodBody: printf("MethodBody\t");break;
		case And: printf("And\t");break;
		case Or: printf("Or\t");break;
		case Lt: printf("Lt\t");break;
		case Gt: printf("Gt\t");break;
		case Eq: printf("Eq\t");break;
		case Neq: printf("Neq\t");break;
		case Leq: printf("Leq\t");break;
		case Geq: printf("Geq\t");break;
		case Add: printf("Add\t");break;
		case Sub: printf("Sub\t");break;
		case Mul: printf("Mul\t");break;
		case Div: printf("Div\t");break;
		case Mod: printf("Mod\t");break;
		case Plus: printf("Plus\t");break;
		case Minus: printf("Minus\t");break;
		case Not: printf("Not\t");break;
		case Length: printf("Length\t");break;
		case NewInt: printf("NewInt\t");break;
		case NewBool: printf("NewBool\t");break;
		case ParseArgs: printf("ParseArgs\t");break;
		case LoadArray: printf("LoadArray\t");break;
		case Store: printf("Store\t");break;
		case StoreArray: printf("StoreArray\t");break;
		case Print: printf("Print\t");break;
		case While: printf("While\t");break;
		case IfElse: printf("IfElse\t");break;
		case If: printf("If\t");break;
		case Null: printf("Null\t");break;
		case CompoundStat: printf("CompoundStat\t");break;
		default: printf("asdasdasdas\t");break;*/
	}
}

//Procura um identificador, devolve 0 caso nao exista
table_element *search_el(char *str_var, char* str_method, int call_search)
{

	table_element *aux;
	table_element *method;

	for(aux=symtab; aux; aux=aux->next)
	{
		if(aux->type!=Program){
			if(aux->type==MethodDecl)
			{
				if(strcmp(aux->name,str_method)==0)
				{
					method=aux;
					if(call_search==1){
						return aux;
					}
					if(call_search==2)
					{
						return method->method_stuff;
					}
					break;
				}
			}
			/*else if(call_search==0)
			{
				if(strcmp(aux->name, str_var)==0)
					return aux;
			}*/
		}
	}

	if(call_search==0)
	{
		for(aux=method->method_stuff->next; aux; aux=aux->next)
		{
			if(strcmp(aux->name,str_var)==0)
			{
				return aux;
			}
		}
	}


	for(aux=symtab; aux; aux=aux->next)
	{
		if(aux->type!=Program){
			if(aux->type==MethodDecl)
			{
				if(strcmp(aux->name,str_method)==0)
				{
					method=aux;
					if(call_search==1){
						return aux;
					}
					if(call_search==2)
					{
						return method->method_stuff;
					}
					
				}
			}
			else if(call_search==0)
			{
				if(strcmp(aux->name, str_var)==0)
					return aux;
			}
		}
	}




	return NULL;
}

table_element *search_param(int param, char* str_method)
{
	table_element *aux;
	table_element *method;
	int count=0;

	for(aux=symtab; aux; aux=aux->next)
	{
			if(aux->type==MethodDecl)
			{
				if(strcmp(aux->name,str_method)==0)
				{
					method=aux;
					break;
				}
			}
	}

	for(aux=method->method_stuff->next; aux; aux=aux->next)
	{
		if(aux->is_param==0){
			return NULL;
		}
		if(param==count)
		{
			return aux;
		}
		else
			count++;
	}

	return NULL;

}




