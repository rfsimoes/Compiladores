#ifndef _STRUCTURES_
#define _STRUCTURES_

typedef enum {Program,Id, VarDecl, MethodDecl, Void, MethodParams,
 			MethodBody, ParamDeclaration, StringArray, CompoundStat,
 			IfElse, Print, Return, Store, StoreArray, While, Or,
 			And, Eq,Neq, Lt, Gt, Leq, Geq, Add, Sub, Mul, Div, Mod,
 			Not, Minus, Plus, Length, LoadArray, Call, NewInt,
 			NewBool, ParseArgs, Int, Bool, IntArray, BoolArray, 
 			 IntLit, BoolLit, If, Null,String} disc_expression;



typedef struct _a2 {
	disc_expression disc_d;

	char  *val;

	struct _a2 *brother;
	struct _a2 *son;
}program_tree;

#endif
