#include "shows.h"
#include "structures.h"
#include <stdlib.h>
#include <stdio.h>

void show_program(program_tree *head, int spaces)
{
	program_tree *aux;
	int i;
	/*printf("numTabs %d \n", numTabs);*/
	aux=head;
	for(i=0 ; i<spaces*2 ; i++)
		printf(" ");
	show_disc(aux->disc_d);
	show_value(aux);
	
	if(aux->son!=NULL)
		show_program(aux->son,spaces+1);
	if(aux->brother!=NULL)
		show_program(aux->brother,spaces);


	/*for(aux=head ; aux!=NULL ; aux=aux->son)
	{
		show_disc(aux->disc_d);
		show_value(aux->val);
	}*/
}

void show_disc(disc_expression d)
{
	switch(d)
	{
		case Program: printf("Program\n");break;
		case Id: printf("Id");break;
		case Int: printf("Int\n");break;
		case Bool: printf("Bool\n");break;
		case VarDecl: printf("VarDecl\n");break;
		case IntArray: printf("IntArray\n");break;
		case BoolArray: printf("BoolArray\n");break;
		case Void: printf("Void\n");break;
		case MethodDecl: printf("MethodDecl\n");break;
		case ParamDeclaration: printf("ParamDeclaration\n");break;
		case StringArray: printf("StringArray\n");break;
		case MethodParams: printf("MethodParams\n");break;
		case Call: printf("Call\n");break;
		case BoolLit: printf("BoolLit");break;
		case IntLit: printf("IntLit");break;
		case Return: printf("Return\n");break;
		case MethodBody: printf("MethodBody\n");break;
		case And: printf("And\n");break;
		case Or: printf("Or\n");break;
		case Lt: printf("Lt\n");break;
		case Gt: printf("Gt\n");break;
		case Eq: printf("Eq\n");break;
		case Neq: printf("Neq\n");break;
		case Leq: printf("Leq\n");break;
		case Geq: printf("Geq\n");break;
		case Add: printf("Add\n");break;
		case Sub: printf("Sub\n");break;
		case Mul: printf("Mul\n");break;
		case Div: printf("Div\n");break;
		case Mod: printf("Mod\n");break;
		case Plus: printf("Plus\n");break;
		case Minus: printf("Minus\n");break;
		case Not: printf("Not\n");break;
		case Length: printf("Length\n");break;
		case NewInt: printf("NewInt\n");break;
		case NewBool: printf("NewBool\n");break;
		case ParseArgs: printf("ParseArgs\n");break;
		case LoadArray: printf("LoadArray\n");break;
		case Store: printf("Store\n");break;
		case StoreArray: printf("StoreArray\n");break;
		case Print: printf("Print\n");break;
		case While: printf("While\n");break;
		case IfElse: printf("IfElse\n");break;
		case If: printf("If\n");break;
		case Null: printf("Null\n");break;
		case CompoundStat: printf("CompoundStat\n");break;
		default: printf("asdasdasdas\n");break;
	}
}

void show_value(program_tree *node)
{

		if(node->val != NULL)
		{
			printf("(%s)\n", node->val);
		}
	



}



