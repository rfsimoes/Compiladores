#include "structures.h"
#include <stdio.h>
#include <stdlib.h>

typedef struct variables_node {
	disc_expression type;
	int is_global;
	char*  method_name;
	char* var_name;
	int numReg;

	struct variables_node *next;

}VNODE;


void code_generator(program_tree* myprogramhead);
void generate_fmdecl(program_tree *fmdecl_node);
void generate_vardec_list(program_tree *node, int scope);
void generate_methoddec(program_tree *type_node);
void generate_methodparams(program_tree *methodparams_node);
void generate_methodbody(program_tree *methodbody_node);
void generate_print(program_tree *print_node);
void generate_store(program_tree *store_node);
char* generate_var_value(program_tree* node);
char* translate_types_to_string(disc_expression type);
VNODE* search_var(program_tree * id_node);
char* do_the_math(program_tree*node);
char* do_the_boolean_math(program_tree*node);
char* do_the_boolean_math(program_tree*node);
char* generate_variable_for_using(VNODE* var);
void print_boolean(char* print_aux);
void generate_return(program_tree* return_node);