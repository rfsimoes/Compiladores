#include "structures.h"
#include "semantics.h"
#include "symbol_table.h"
#include "shows.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int check_program(program_tree* p)
{
	int errorcount=0;
	check_class(p->son);
	errorcount+=check_fmdecl(p->son->brother);

	
	/*errorcount=check_vardec_list(p->vlist);
	errorcount+=check_statement_list(p->slist);*/
	
	return errorcount;
}

int check_fmdecl(program_tree *node) /*node vardecl or methoddecl*/
{
	int errorcount=0;
	if(node != NULL)
	{
		program_tree* tmp;
	
		for(tmp=node; tmp; tmp=tmp->brother)
		{
			switch(tmp->disc_d)
			{
				case VarDecl: errorcount+=check_vardec_list(tmp->son);if(errorcount>0)return 1;break;
				case MethodDecl: errorcount+=check_methoddec(tmp->son);if(errorcount>0)return 1;break;
			}
		}
	}

	if(node != NULL)
	{
		program_tree* tmp;
	
		for(tmp=node; tmp; tmp=tmp->brother)
		{
			switch(tmp->disc_d)
			{
				case MethodDecl: errorcount+=check_method_params(tmp);if(errorcount>0)return 1;break;
			}
		}
	}

	if(node != NULL)
	{
		program_tree* tmp;
	
		for(tmp=node; tmp; tmp=tmp->brother)
		{
			switch(tmp->disc_d)
			{
				case MethodDecl: errorcount+=check_method_elems(tmp);if(errorcount>0)return 1;break;
			}
		}
	}
	
	return errorcount;
}

int check_method_params(program_tree *MethodDecl_node)
{
	int errorcount=0,aux=0;
	program_tree* type_node=MethodDecl_node->son;
	program_tree* id_node=type_node->brother;
	program_tree* methodparams_node=NULL;
	program_tree* methodbody_node=NULL;
	program_tree* aux_node;
	switch(id_node->brother->disc_d)
	{
		case MethodParams: methodparams_node = id_node->brother;aux=1;break;
		case MethodBody: methodbody_node=id_node->brother;aux=2;break;
	}
	
	if(aux==1)
	{
		methodbody_node=methodparams_node->brother;
	}

	if(methodparams_node!=NULL)
	{
		/*check params*/
		for(aux_node=methodparams_node->son; aux_node ; aux_node=aux_node->brother)
		{
			errorcount+=check_method_param(aux_node,id_node);
			if(errorcount>0)
				return 1;
		}
	}
}

int check_method_elems(program_tree *MethodDecl_node)
{

	int errorcount=0,aux=0;
	program_tree* type_node=MethodDecl_node->son;
	program_tree* id_node=type_node->brother;
	program_tree* methodparams_node=NULL;
	program_tree* methodbody_node=NULL;
	program_tree* aux_node;
	switch(id_node->brother->disc_d)
	{
		case MethodParams: methodparams_node = id_node->brother;aux=1;break;
		case MethodBody: methodbody_node=id_node->brother;aux=2;break;
	}
	
	if(aux==1)
	{
		methodbody_node=methodparams_node->brother;
	}

	if(methodbody_node!=NULL)
	{
		/*check method body*/
		for(aux_node=methodbody_node->son; aux_node ; aux_node=aux_node->brother)
		{
			switch(aux_node->disc_d)
			{
				case VarDecl:errorcount+=check_method_vardec_list(aux_node,id_node);if(errorcount>0)return 1;break;
				default: errorcount+=check_method_body_for_errors(aux_node,id_node->val,MethodDecl_node);if(errorcount>0)return 1;break;
			}
			
		}
	}

	


	return errorcount;
}

int check_method_body_for_errors(program_tree* node, char* method_name,program_tree *MethodDecl_node)
{
	int errorcount=0;
	disc_expression type,type2,type3;
	table_element *aux;
	if(node!=NULL)
	{
		if(node->disc_d==IfElse)
		{
			type=check_type(node->son,method_name);
			if(type!=BoolLit && type!=Bool)
			{
				printf("Incompatible type in if statement (got %s, required boolean)\n", convert_types_to_string(type));
				exit(0);
			}
		
		}
		else if(node->disc_d==While)
		{
			type=check_type(node->son,method_name);
			if(type!=BoolLit && type!=Bool)
			{
				printf("Incompatible type in while statement (got %s, required boolean)\n", convert_types_to_string(type));
				exit(0);
			}

		}
		else if(node->disc_d==Print)
		{
			type=check_type(node->son,method_name);
			if(type==IntArray || type==BoolArray || type==StringArray)
			{
				printf("Incompatible type in System.out.println statement (got %s, required boolean or int)\n", convert_types_to_string(type));
				exit(0);
			}
		}
		else if(node->disc_d==Return)
		{
			type=check_type(node->son,method_name);
			type2 = MethodDecl_node->son->disc_d;
			if(type!=type2)
			{
				printf("Incompatible type in return statement (got %s, required %s)\n",convert_types_to_string(type),convert_types_to_string(type2));
				exit(0);;
			}

		}
		else if(node->disc_d==Store)
		{
			type=check_type(node->son,method_name);
			type2=check_type(node->son->brother,method_name);
			if(type!=type2 )
			{
				printf("Incompatible type in assignment to %s (got %s, required %s)\n",  node->son->val,convert_types_to_string(type2),convert_types_to_string(type));
				exit(0);
			}
		}
		else if(node->disc_d==StoreArray)
		{
			type=check_type(node->son,method_name);
			type2=check_type(node->son->brother,method_name);
			type3=check_type(node->son->brother->brother,method_name);
			
			if((type!=IntArray && type!=BoolArray) || type2!=Int)
			{
				printf("Operator [ cannot be applied to types %s, %s\n", convert_types_to_string(type),convert_types_to_string(type2));
				exit(0);
			}
			if(type==IntArray && type3!=Int)
			{
				printf("Incompatible type in assignment to %s[] (got %s, required int)\n", node->son->val,convert_types_to_string(type3));
				exit(0);
			}
			if(type==BoolArray && type3!=Bool)
			{
				printf("Incompatible type in assignment to %s[] (got %s, required boolean)\n", node->son->val,convert_types_to_string(type3));
				exit(0);
			}
			if(type==StringArray && type3!=String)
			{
				printf("Incompatible type in assignment to %s[] (got %s, required String)\n", node->son->val,convert_types_to_string(type3));
				exit(0);
			}

			
		}

		if(node->son!=NULL){
			errorcount+=check_method_body_for_errors(node->son,method_name,MethodDecl_node);if(errorcount>0)return 1;
		}
		if(node->brother!=NULL){
			errorcount+=check_method_body_for_errors(node->brother,method_name,MethodDecl_node);if(errorcount>0)return 1;
		}

	}

	return 0;
}

disc_expression check_type(program_tree *node, char* method_name)
{
	disc_expression type1,type2;
	table_element *aux;
	table_element *type_param;
	program_tree *aux2;
	char*Op;
	char*t1;
	char*t2;
	int param=0;
	char num1,num2,num3;
	int len;
	int i;
	if(node!=NULL)
	{
		switch(node->disc_d)
		{
			case IntLit:
				len = strlen(node->val);
				if(len>=2)
				{
					num1=(node->val)[0];
					num2=(node->val)[1];
					if(num1==48 && num2!=120)
					{
						for (i = 0; i < len; ++i)
						{
							num1=(node->val)[i];
							if(num1<48 || num1>55)
							{
								printf("Invalid literal %s\n", node->val);
								exit(0);
							}
						}
					}
				}				
				/*num1=(node->val)[0];
				num2=(node->val)[1];
				if(num1==48)
				{
					if(num2>47 && num2<58)
					{
						printf("Invalid literal %s\n", node->val);
						exit(0);
					}
				}*/

				return Int; break;
			case BoolLit: return Bool; break;
			case IntArray: return IntArray; break;
			case StringArray: return StringArray; break;
			case BoolArray: return BoolArray; break;
			case And:
			case Or:
				type1 = check_type(node->son,method_name);
				type2 = check_type(node->son->brother,method_name);
				if(type1==Bool && type2==Bool){
					return Bool;
				}
				else
				{
					Op=convert_types_to_string(node->disc_d);
					t1=convert_types_to_string(type1);
					t2=convert_types_to_string(type2);
					printf("Operator %s cannot be applied to types %s, %s\n", Op,t1,t2);
					exit(0);
				}
				break;
			case Geq:
			case Leq:
			case Gt:
			case Lt:
				type1 = check_type(node->son,method_name);
				type2 = check_type(node->son->brother,method_name);
				if(type1==type2 && type1==Int){
					return Bool;
				}
				else
				{
					Op=convert_types_to_string(node->disc_d);
					t1=convert_types_to_string(type1);
					t2=convert_types_to_string(type2);
					printf("Operator %s cannot be applied to types %s, %s\n", Op,t1,t2);
					exit(0);
				}
				break;
			case Neq:
			case Eq:
				type1 = check_type(node->son,method_name);
				type2 = check_type(node->son->brother,method_name);
				if(type1==type2){
					return Bool;
				}
				else
				{
					Op=convert_types_to_string(node->disc_d);
					t1=convert_types_to_string(type1);
					t2=convert_types_to_string(type2);
					printf("Operator %s cannot be applied to types %s, %s\n", Op,t1,t2);
					exit(0);
				}
				break;
			case Add:
			case Sub:
			case Mul:
			case Div:
			case Mod:
				type1 = check_type(node->son,method_name);
				type2 = check_type(node->son->brother,method_name);
				if(type1==Int && type2==Int ){
					return Int;
				}
				else
				{
					Op=convert_types_to_string(node->disc_d);
					t1=convert_types_to_string(type1);
					t2=convert_types_to_string(type2);
					printf("Operator %s cannot be applied to types %s, %s\n", Op,t1,t2);
					exit(0);
				}
				break;
			case Id:
				if((aux=search_el(node->val,method_name,0))==NULL){
					printf("Cannot find symbol %s\n", node->val);
					exit(0);
				}
				else{
					return aux->type;
				}
				break;
			case LoadArray:
				type1 = check_type(node->son,method_name);
				type2 = check_type(node->son->brother,method_name);
				if((type1!=IntArray && type1!=BoolArray) || type2!=Int)
				{
					Op=convert_types_to_string(node->disc_d);
					t1=convert_types_to_string(type1);
					t2=convert_types_to_string(type2);
					printf("Operator %s cannot be applied to types %s, %s\n", Op,t1,t2);
					exit(0);
				}

				switch(type1)
				{
					case IntArray: return Int;
					case BoolArray: return Bool;
				}
				break;
			case Call:
				if((aux=search_el("",node->son->val,2))==NULL){
					printf("Cannot find symbol %s\n", node->son->val);
					exit(0);
				}

				for(aux2=node->son->brother ; aux2 ; aux2=aux2->brother)
				{
					type1 = check_type(aux2,method_name);
					type_param=search_param(param,node->son->val);
					if(type_param==NULL)
						type2=Void;
					else
						type2=type_param->type;
					if(type1!=type2)
					{
						printf("Incompatible type of argument %d in call to method %s (got %s, required %s)\n", param,node->son->val,convert_types_to_string(type1),convert_types_to_string(type2));
						exit(0);
					}

					param++;
				}
				type1 = check_type(aux2,method_name);
				type_param=search_param(param,node->son->val);
				if(type_param==NULL)
					type2=Void;
				else
					type2=type_param->type;
				if(type1!=type2)
				{
					printf("Incompatible type of argument %d in call to method %s (got %s, required %s)\n", param,node->son->val,convert_types_to_string(type1),convert_types_to_string(type2));
					exit(0);
				}

				return aux->type;
				break;
			case Minus:
			case Plus:
				type1 = check_type(node->son,method_name);
				if(type1!=Int)
				{
					Op=convert_types_to_string(node->disc_d);
					t1=convert_types_to_string(type1);
					printf("Operator %s cannot be applied to type %s\n", Op,t1);
					exit(0);
				}
				return type1; 
				break;
			case ParseArgs:
				type1 = check_type(node->son,method_name);
				type2 = check_type(node->son->brother,method_name);
				if(type1==StringArray && type2==Int)
					return Int;
				else
				{
					Op=convert_types_to_string(node->disc_d);
					t1=convert_types_to_string(type1);
					t2=convert_types_to_string(type2);

					printf("Operator %s cannot be applied to types %s, %s\n", Op,t1,t2);
					exit(0);
				}
				break;
			case Length:
				type1 = check_type(node->son,method_name);
				if(type1==Bool || type1==BoolLit || type1==IntLit || type1==Int || type1==String)
				{
					printf("Operator .length cannot be applied to type %s\n", convert_types_to_string(type1));
					exit(0);
				}
				return Int;
				break;
			case Not:
				type1 = check_type(node->son,method_name);
				if(type1!=BoolLit && type1!=Bool)
				{
					t1=convert_types_to_string(type1);
					printf("Operator ! cannot be applied to type %s\n",t1);
					exit(0);
				}
				return type1; 
				break;
			case NewInt:
			case NewBool:
				type1 = check_type(node->son,method_name);
				if(type1!=Int)
				{
					t1=convert_types_to_string(type1);
					printf("Operator %s cannot be applied to type %s\n",convert_types_to_string(node->disc_d),t1);
					exit(0);
				}
				if(node->disc_d==NewInt)
					return IntArray;
				else 
					return BoolArray; 
				break;

		}
	}

	return Void;
}

char* convert_types_to_string(disc_expression type)
{
	char* str_type;
	switch(type)
	{
		case Geq: str_type=">="; break;
		case Leq: str_type="<="; break;
		case Gt: str_type=">"; break;
		case Lt: str_type="<"; break;
		case Neq: str_type="!="; break;
		case Eq: str_type="=="; break;
		case And: str_type="&&"; break;
		case Or: str_type="||"; break;
		case Add: str_type="+"; break;
		case Sub: str_type="-"; break;
		case Mul: str_type="*"; break;
		case Div: str_type="/"; break;
		case Mod: str_type="%"; break;
		case Minus: str_type="-"; break;
		case Plus: str_type="+"; break;
		case LoadArray: str_type="["; break;
		case IntArray: str_type="int[]"; break;
		case StringArray: str_type="String[]"; break;
		case BoolArray: str_type="boolean[]"; break;
		case String: str_type="String"; break;
		case Int:
		case IntLit: str_type="int"; break;
		case Bool:
		case BoolLit: str_type="boolean"; break;
		case Void: str_type="void"; break;
		case ParseArgs: str_type="Integer.parseInt"; break;
		case NewInt: str_type="new int"; break;
		case NewBool: str_type="new boolean"; break;
		default: str_type="null";
	}
	return str_type;
}

int check_method_vardec_list(program_tree* vardecl_node, program_tree* id_node)
{
	int errorcount=0;
	program_tree* var_node_aux;
	program_tree* aux;
	program_tree* type_node;

	if(vardecl_node!=NULL)
	{   
			type_node=vardecl_node->son;
			for(aux=type_node->brother ; aux ; aux=aux->brother)
			{
				errorcount+=check_method_vardec(type_node,aux->val,id_node);
				if(errorcount>0)
					return 1;
			}
	}

	return errorcount;
}

int check_method_vardec(program_tree* type_node,char* str, program_tree* id_node)
{   

	table_element* newel=insert_el_in_method(type_node->disc_d,str,id_node->val,0);
	
	if(newel==NULL)
	{
		printf("Symbol %s already defined\n", str);
		return 1;
	}
	return 0;


}

int check_method_param(program_tree* paramdec_node, program_tree* id_node)
{

	table_element* newel=insert_el_in_method(paramdec_node->son->disc_d,paramdec_node->son->brother->val, id_node->val,1);
	
	if(newel==NULL)
	{
		printf("Symbol %s already defined\n", paramdec_node->son->brother->val);
		return 1;
	}
	return 0;
}


int check_methoddec(program_tree* type_node)
{   

	table_element* newel=insert_el_method(type_node->brother->val,type_node->disc_d);
	
	if(newel==NULL)
	{
		printf("Symbol %s already defined\n", type_node->brother->val);
		return 1;
	}
	return 0;


}


void check_class(program_tree *classe)
{
	insert_el(classe->val, Program, 0, 0);
}

int check_vardec_list(program_tree* type_node)
{
	int errorcount=0;
	program_tree* id_node;

	if(type_node!=NULL)
	{   
		for(id_node=type_node->brother; id_node; id_node=id_node->brother)
			errorcount+=check_vardec(type_node,id_node);
	}

	return errorcount;
}

int check_vardec(program_tree* type_node, program_tree* id_node)
{   

	table_element* newel=insert_el(id_node->val,type_node->disc_d,0,-1);
	
	if(newel==NULL)
	{
		printf("Symbol %s already defined\n", id_node->val);
		return 1;
	}
	return 0;


}
