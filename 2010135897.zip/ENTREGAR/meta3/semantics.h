#include "structures.h"
#include "symbol_table.h"


int check_program(program_tree* p);
int check_vardec_list(program_tree* type_node);
int check_vardec(program_tree* type_node, program_tree* id_node);
int check_integer_dec(program_tree* iid);
int check_character_dec(program_tree* icd);
int check_double_dec(program_tree* idd);
int check_statement_list(program_tree* isl);
int check_statement(program_tree* is);
int check_write_statement(program_tree* iws);
void check_class(program_tree *classe);
int check_methoddec(program_tree* type_node);
int check_method_elems(program_tree *MethodDecl_node);
int check_method_param(program_tree* paramdec_node, program_tree* id_node);
int check_method_vardec(program_tree* type_node,char* str, program_tree* id_node);
int check_method_vardec_list(program_tree* vardecl_node, program_tree* id_node);
int check_method_body_for_errors(program_tree* node, char* method_name,program_tree *MethodDecl_node);
disc_expression check_type(program_tree *node,char *method_name);
char* convert_types_to_string(disc_expression type);
int check_method_params(program_tree *MethodDecl_node);
