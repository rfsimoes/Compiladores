#ifndef SYMBOL_TABLE_H
#define SYMBOL_TABLE_H
#include "structures.h"


typedef struct _t1{
	char name[100];
	disc_expression type;
	int is_param;
	char title[100];
	struct _t1 *next;
	struct _t1 *method_stuff;
} table_element;

table_element *insert_el(char *str, disc_expression t, int is_param, int title_type);
void show_type(disc_expression d);
table_element *search_el(char *str_var, char* str_method, int call_search);
table_element *insert_el_method(char *str, disc_expression t);
table_element *insert_el_in_method(disc_expression t, char* str_var, char* str_method, int is_param);
table_element *search_param(int param, char* method);

#endif
