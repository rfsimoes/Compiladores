#include "structures.h"

void show_program(program_tree *head, int numTabs);
void show_disc(disc_expression d);
void show_value(program_tree *node);


