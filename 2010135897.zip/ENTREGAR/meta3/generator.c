#include "generator.h"
#include "semantics.h"
#include "shows.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

VNODE *vars=NULL;
int variables=1;
char *method_name = " ";
disc_expression return_type;
int returned=0;
int print_bool=0;

void code_generator(program_tree* myprogramhead)
{

	/*prints*/
	printf("@.str = private unnamed_addr constant [4 x i8] c\"%%d\\0A\\00\"\n");
	printf("@.str1 = private unnamed_addr constant [4 x i8] c\"%%s\\0A\\00\"\n");
	printf("@.str2 = private unnamed_addr constant [7 x i8] c\"false\\0A\\00\"\n");
	printf("@.str3 = private unnamed_addr constant [6 x i8] c\"true\\0A\\00\"\n");

	generate_fmdecl(myprogramhead->son->brother);

	printf("declare i32 @printf(i8*, ...)\n");
	printf("declare i32 @atoi(i8*) nounwind readonly\n");
}

void generate_fmdecl(program_tree *node)
{
	if(node!=NULL)
	{
		program_tree* tmp;
	
		for(tmp=node; tmp; tmp=tmp->brother)
		{
			switch(tmp->disc_d)
			{
				case VarDecl: generate_vardec_list(tmp->son,0);break;
				case MethodDecl: generate_methoddec(tmp->son);break;
			}
		}

	}
}

char* translate_types_to_string(disc_expression type)
{
	switch(type)
	{
		case Int:return "i32";break;
		case IntArray:return "i32*";break;
		case Bool:return "i1";break;
		case BoolArray:return "i1*";break;
		case StringArray:return "i8**";break;
	}

}

void generate_vardec_list(program_tree *type_node, int scope)
{
	program_tree* id_node;
	VNODE *aux;
	VNODE *tmp;

	if(type_node!=NULL)
	{   
		for(id_node=type_node->brother; id_node; id_node=id_node->brother)
		{
			aux=(VNODE*) malloc(sizeof(VNODE));

			if(scope == 0)
			{
				switch(type_node->disc_d)
				{
					case Int:
					case Bool:printf("@%s = common global %s 0\n", id_node->val,translate_types_to_string(type_node->disc_d));break;
					case IntArray:
					case BoolArray:
					case StringArray:printf("@%s = common global %s null\n", id_node->val,translate_types_to_string(type_node->disc_d));break;
				}
				aux->is_global = 1;
			}
			else
			{
				printf("\t%%%s = alloca %s\n", id_node->val,translate_types_to_string(type_node->disc_d));
				aux->is_global = 0; 
			}

			aux->type = type_node->disc_d;
			aux->method_name = method_name;
			aux->var_name = id_node->val;
			aux->numReg = 0;
			if(vars==NULL)
				vars = aux;
			else
			{
				tmp=vars;
				while(tmp->next!=NULL)
					tmp=tmp->next;
				tmp->next = aux;
			}
			
		}
	}

}

void generate_methoddec(program_tree *type_node)
{	
	method_name = " ";
	returned = 0;
	method_name = type_node->brother->val;
	variables=1;
	if(type_node!=NULL)
	{
		return_type = type_node->disc_d;
		if(strcmp(method_name,"main")==0)
			printf("define i32 @%s(", type_node->brother->val);
		else{
			switch(type_node->disc_d)
			{
				case Int:printf("define i32 @%s(", type_node->brother->val);break;
				case IntArray:printf("define i32* @%s(", type_node->brother->val);break;
				case Bool:printf("define i1 @%s(", type_node->brother->val);break;
				case BoolArray:printf("define i1* @%s(", type_node->brother->val);break;
				case Void:printf("define void @%s(", type_node->brother->val);break;
				case StringArray:printf("define char** @%s(\n", type_node->brother->val);break;
			}
		}

		generate_methodparams(type_node->brother->brother);

		generate_methodbody(type_node->brother->brother->brother);
		if(strcmp(method_name,"main")==0 && returned==0)
			printf("\tret i32 0\n");
		/*else if(strcmp(method_name,"main")==0 && returned==0 && return_type==Void)
			printf("\tret void\n");*/
		else if(returned==0)
			printf("\tret %s 0\n", translate_types_to_string(return_type));
		printf("}\n");

	}

}

void generate_methodbody(program_tree *methodbody_node)
{
	program_tree* tmp;
	int counter=0;

	if(methodbody_node!=NULL)
	{
		tmp=methodbody_node;	

		switch(tmp->disc_d)
		{
			case VarDecl:generate_vardec_list(tmp->son,1);break;
			case Print:generate_print(tmp);break;
			case Store:generate_store(tmp);break;
			case StoreArray:break;
			case IfElse:break;
			case Return:generate_return(tmp);break;
			case While:break;

		}

		generate_methodbody(tmp->son);
		generate_methodbody(tmp->brother);

	}
}

void generate_return(program_tree* return_node)
{
	char*aux;
	VNODE* varaux;
	char*print_aux;
	char*var;
	long int li;
	char*buffer = (char*)malloc(10*sizeof(char));
	if(return_node!=NULL)
	{
		if(return_node->son == NULL)
		{				
			printf("\tret void\n");
			returned = 1;
			return;
		}
		switch(return_node->son->disc_d)
		{
			case IntLit:
				if((return_node->son->val)[0]==48 && (return_node->son->val)[1]==120)
				{
					li = strtol(return_node->son->val,NULL,16);
					snprintf(buffer,10,"%ld",li);
					printf("\tret %s %s\n", translate_types_to_string(return_type),buffer);
				}
				else if((return_node->son->val)[0]==48 && (return_node->son->val)[1]!=120)
				{
					li = strtol(return_node->son->val,NULL,8);
					snprintf(buffer,10,"%ld",li);
					printf("\tret %s %s\n", translate_types_to_string(return_type),buffer);
				}
				else{
				printf("\tret %s %s\n", translate_types_to_string(return_type),return_node->son->val);}
				returned = 1;
				break;
			case BoolLit:
				if (strcmp(return_node->son->val,"false")==0)
					printf("\tret %s %d\n", translate_types_to_string(return_type),0);
				else
					printf("\tret %s %d\n", translate_types_to_string(return_type),1);
				returned=1;
				break;
			case Id:
				returned = 1;
				varaux = search_var(return_node->son);
				print_aux = generate_variable_for_using(varaux);
				printf("\tret %s %s\n", translate_types_to_string(return_type),print_aux);
				break;
			case ParseArgs: 
				var = generate_var_value(return_node->son);
				printf("\t%%%d = load i8*** %%%s\n", variables,var);
				variables++;
				if(return_node->son->son->brother->disc_d == Id){
					varaux = search_var(return_node->son->son->brother);
					print_aux = generate_variable_for_using(varaux);
					printf("\t%%%d = add nsw i32 1, %s\n",variables,print_aux);
					variables++;
					printf("\t%%%d = getelementptr inbounds i8** %%%d, i32 %%%d\n", variables,variables-3,variables-1);
					variables++;
				}
				else if(return_node->son->son->brother->disc_d == IntLit)
				{
					if((return_node->son->son->brother->val)[0]==48 && (return_node->son->son->brother->val)[1]==120)
					{
						li = strtol(return_node->son->son->brother->val,NULL,16);
						li++;
						snprintf(buffer,10,"%ld",li);
						printf("\t%%%d = getelementptr inbounds i8** %%%d, i32 %s\n", variables,variables-1,buffer);
					}
					else if((return_node->son->son->brother->val)[0]==48 && (return_node->son->son->brother->val)[1]!=120)
					{
						li = strtol(return_node->son->son->brother->val,NULL,8);
						li++;
						snprintf(buffer,10,"%ld",li);
						printf("\t%%%d = getelementptr inbounds i8** %%%d, i32 %s\n", variables,variables-1,buffer);
					}
					else{
						printf("\t%%%d = getelementptr inbounds i8** %%%d, i32 %d\n", variables,variables-1,atoi(return_node->son->son->brother->val)+1);
					}
					variables++;
				}
				
				printf("\t%%%d = load i8** %%%d\n", variables,variables-1);
				variables++;
				printf("\t%%%d = call i32 @atoi(i8* %%%d) nounwind readonly\n", variables,variables-1);
				variables++;

				printf("\tret %s %%%d\n", translate_types_to_string(return_type),variables-1);
				returned=1;
				break;
			case Add:
			case Sub:
			case Div:
			case Mul:
			case Mod:
			case Minus:
			case Plus:
				print_aux = do_the_math(return_node->son);
				printf("\tret %s %s\n", translate_types_to_string(return_type),print_aux);
				returned=1;
				break;
			/*case Call:
				do_the_math(son);
				printf("\t%%%d = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([4 x i8]* @.str, i32 0, i32 0), i32 %%%d)\n",variables,variables-1 );
				variables++;
				break;*/
			case And:
			case Or:
			case Geq:
			case Leq:
			case Gt:
			case Lt:
			case Eq:
			case Neq:
			case Not:
				print_aux = do_the_boolean_math(return_node->son);
				printf("\tret %s %s\n", translate_types_to_string(return_type),print_aux);
				returned=1;
				break;				
		
		}
	}

}

void generate_store(program_tree *store_node)
{
	disc_expression type;
	VNODE *varAux;
	VNODE* varaux;
	char* var;
	char*print_aux,*print_aux2;
	long int li;
	char *buffer = (char*)malloc(10*sizeof(char));

	if(store_node != NULL)
	{
		type = check_type(store_node->son,method_name);
		switch(type)
		{
			case Int:
			
				switch(store_node->son->brother->disc_d)
				{
					case IntLit:
						varaux = search_var(store_node->son);
						
						if(varaux->is_global==1)
							print_aux = "@";
						else
							print_aux = "%";

						if((store_node->son->brother->val)[0]==48 && (store_node->son->brother->val)[1]==120)
						{
 							li = strtol(store_node->son->brother->val,NULL,16);
 							snprintf(buffer,10,"%ld",li);
 							printf("\tstore i32 %s, i32* %s%s\n",buffer,print_aux,store_node->son->val);
 							break;
						}
						else if((store_node->son->brother->val)[0]==48 && (store_node->son->brother->val)[1]!=120)
						{
 							li = strtol(store_node->son->brother->val,NULL,8);
 							snprintf(buffer,10,"%ld",li);
 							printf("\tstore i32 %s, i32* %s%s\n",buffer,print_aux,store_node->son->val);
 							break;
						}
						else
							printf("\tstore i32 %s, i32* %s%s\n",store_node->son->brother->val,print_aux,store_node->son->val);
							break;
					case Id: 
						varaux = search_var(store_node->son->brother);
						print_aux = generate_variable_for_using(varaux);
						varaux = search_var(store_node->son);
						
						if(varaux->is_global==1)
							print_aux2 = "@";
						else
							print_aux2 = "%";

						printf("\tstore i32 %s, i32* %s%s\n", print_aux,print_aux2,varaux->var_name);
						break;
					case ParseArgs: 
						var = generate_var_value(store_node->son->brother);
						printf("\t%%%d = load i8*** %%%s\n", variables,var);
						variables++;
						if(store_node->son->brother->son->brother->disc_d == Id){
							varaux = search_var(store_node->son->brother->son->brother);
							print_aux = generate_variable_for_using(varaux);
							printf("\t%%%d = add nsw i32 1, %s\n",variables,print_aux);
							variables++;
							printf("\t%%%d = getelementptr inbounds i8** %%%d, i32 %%%d\n", variables,variables-3,variables-1);
							variables++;
						}
						else if(store_node->son->brother->son->brother->disc_d == IntLit)
						{

							if((store_node->son->brother->son->brother->val)[0]==48 && (store_node->son->brother->son->brother->val)[1]==120)
							{
	 							li = strtol(store_node->son->brother->son->brother->val,NULL,16);
	 							li++;
	 							snprintf(buffer,10,"%ld",li);
	 							printf("\t%%%d = getelementptr inbounds i8** %%%d, i32 %s\n", variables,variables-1,buffer);
							}
							else if((store_node->son->brother->son->brother->val)[0]==48 && (store_node->son->brother->son->brother->val)[1]!=120)
							{
	 							li = strtol(store_node->son->brother->son->brother->val,NULL,8);
	 							li++;
	 							snprintf(buffer,10,"%ld",li);
	 							printf("\t%%%d = getelementptr inbounds i8** %%%d, i32 %s\n", variables,variables-1,buffer);
							}
							else
								printf("\t%%%d = getelementptr inbounds i8** %%%d, i32 %d\n", variables,variables-1,atoi(store_node->son->brother->son->brother->val)+1);
							variables++;
						}
						

						printf("\t%%%d = load i8** %%%d\n", variables,variables-1);
						variables++;
						printf("\t%%%d = call i32 @atoi(i8* %%%d) nounwind readonly\n", variables,variables-1);
						variables++;

						varaux = search_var(store_node->son);
						
						if(varaux->is_global==1)
							print_aux = "@";
						else
							print_aux = "%";

						printf("\tstore i32 %%%d, i32* %s%s\n", variables-1,print_aux,store_node->son->val);
						break;
					case Add:
					case Sub:
					case Mul:
					case Div:
					case Mod:
						do_the_math(store_node->son->brother);
						varaux = search_var(store_node->son);
						
						if(varaux->is_global==1)
							print_aux = "@";
						else
							print_aux = "%";

						printf("\tstore i32 %%%d, i32* %s%s\n", variables-1,print_aux,varaux->var_name);
						break;
					/*case Call:
						do_the_math(store_node->son->brother);
						
						varaux = search_var(store_node->son);
						
						if(varaux->is_global==1)
							print_aux = "@";
						else
							print_aux = "%";

						printf("\tstore i32 %%%d, i32* %s%s\n", variables-1,print_aux,store_node->son->val);
						break;*/
					case Length:
						print_aux = do_the_math(store_node->son->brother);	
						varaux = search_var(store_node->son);
						
						if(varaux->is_global==1)
							print_aux2 = "@";
						else
							print_aux2 = "%";

						printf("\tstore i32 %s, i32* %s%s\n", print_aux,print_aux2,varaux->var_name);
						break;
				}
				break;
			case Bool:
				switch(store_node->son->brother->disc_d)
				{
					case BoolLit:
						varaux = search_var(store_node->son);
						
						if(varaux->is_global==1)
							print_aux = "@";
						else
							print_aux = "%";

						if(strcmp(store_node->son->brother->val,"false")==0)
							print_aux2 = "0";
						else
							print_aux2 = "1";

						printf("\tstore i1 %s, i1* %s%s\n",print_aux2,print_aux,store_node->son->val);break;
					case Id: 
						varaux = search_var(store_node->son->brother);
						print_aux = generate_variable_for_using(varaux);
						varaux = search_var(store_node->son);
						
						if(varaux->is_global==1)
							print_aux2 = "@";
						else
							print_aux2 = "%";

						printf("\tstore i1 %s, i1* %s%s\n", print_aux,print_aux2,varaux->var_name);
						break;
					case And:
					case Or:
					case Geq:
					case Leq:
					case Gt:
					case Lt:
					case Eq:
					case Neq:
					case Not:
						print_aux = do_the_boolean_math(store_node->son->brother);
						varaux = search_var(store_node->son);
						
						if(varaux->is_global==1)
							print_aux = "@";
						else
							print_aux = "%";

						printf("\tstore i1 %%%d, i1* %s%s\n", variables-1,print_aux,varaux->var_name);
						break;
					/*case Call:
						do_the_math(store_node->son->brother);
						
						varaux = search_var(store_node->son);
						
						if(varaux->is_global==1)
							print_aux = "@";
						else
							print_aux = "%";

						printf("\tstore i1 %%%d, i1* %s%s\n", variables-1,print_aux,store_node->son->val);
						break;*/
				}
				break;

		}
	}
}

char* generate_variable_for_using(VNODE* var)
{
	char* var_aux = (char*)malloc(10*sizeof(char));

	if(var->numReg == 0)
	{
		if(var->is_global==1)
			printf("\t%%%d = load %s* @%s\n",variables,translate_types_to_string(var->type),var->var_name);
		else
			printf("\t%%%d = load %s* %%%s\n",variables,translate_types_to_string(var->type),var->var_name);
		snprintf(var_aux,10,"%%%d",variables);
		var->numReg = variables;
		variables++;
	}
	else
	{
		snprintf(var_aux,10,"%%%d",var->numReg);
	}
	return var_aux;
}

char* generate_var_value(program_tree* node)
{
	long int li;
	char* buffer = (char*)malloc(10*sizeof(char));

	if(node!=NULL)
	{
		switch(node->disc_d)
		{
			case IntLit: 
				if((node->val)[0]==48 && (node->val)[1]==120)
				{
					li = strtol(node->val,NULL,16);
					snprintf(buffer,10,"%ld",li);
					return buffer;
					break;
				}
				else if((node->val)[0]==48 && (node->val)[1]!=120)
				{
					li = strtol(node->val,NULL,8);
					snprintf(buffer,10,"%ld",li);
					return buffer;
					break;
				}
				else
					{return node->val;break;}
			case Id: return node->val;break;
			case ParseArgs: return "2"; break;
		}
	}
}

void generate_print(program_tree *print_node)
{
	program_tree *son;
	disc_expression type;
	VNODE *varaux;
	char*print_aux;
	char*var;
	char*buffer = (char*)malloc(10*sizeof(char));
	long int li;

	if(print_node!=NULL)
	{
		son = print_node->son;

		switch(son->disc_d)
		{
			case IntLit:
				if((son->val)[0]==48 && (son->val)[1]==120)
				{
					li = strtol(son->val,NULL,16);
					snprintf(buffer,10,"%ld",li);
					printf("\t%%%d = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([4 x i8]* @.str, i32 0, i32 0), i32 %s)\n", variables,buffer);variables++;break;
				}
				else if((son->val)[0]==48 && (son->val)[1]!=120)
				{
					li = strtol(son->val,NULL,8);
					snprintf(buffer,10,"%ld",li);
					printf("\t%%%d = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([4 x i8]* @.str, i32 0, i32 0), i32 %s)\n", variables,buffer);variables++;break;
				}
				else{
					printf("\t%%%d = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([4 x i8]* @.str, i32 0, i32 0), i32 %s)\n", variables,son->val);variables++;break;
				}
			case BoolLit:
				if (strcmp(son->val,"false")==0){
					printf("\t%%%d = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([7 x i8]* @.str2, i32 0, i32 0))\n",variables);
					variables++;
				}
				else
				{
					printf("\t%%%d = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([6 x i8]* @.str3, i32 0, i32 0))\n",variables);
					variables++;
				}
				break;
			case Id: 
				varaux = search_var(son);
				if(varaux->type==Int){
					print_aux = generate_variable_for_using(varaux);
					printf("\t%%%d = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([4 x i8]* @.str, i32 0, i32 0), i32 %s)\n",variables,print_aux );
					variables++;
				}
				else if(varaux->type==Bool)
				{
					if(varaux->is_global==1)
						snprintf(buffer, 10, "@%s",son->val);
					else
						snprintf(buffer, 10, "%%%s",son->val);
					print_boolean(buffer);
					break;	
				}
				break;
			case ParseArgs: 
				var = generate_var_value(print_node->son);
				varaux = search_var(print_node->son->son->brother);
				print_aux = generate_variable_for_using(varaux);
				printf("\t%%%d = load i8*** %%%s\n", variables,var);
				variables++;
				printf("\t%%%d = add nsw i32 1, %s\n",variables,print_aux);
				variables++;
				printf("\t%%%d = getelementptr inbounds i8** %%%d, i32 %%%d\n", variables,variables-2,variables-1);
				variables++;
				printf("\t%%%d = load i8** %%%d\n", variables,variables-1);
				variables++;
				printf("\t%%%d = call i32 @atoi(i8* %%%d) nounwind readonly\n", variables,variables-1);
				variables++;
				printf("\t%%%d = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([4 x i8]* @.str, i32 0, i32 0), i32 %%%d)\n",variables,variables-1 );
				variables++;
				break;
			case Add:
			case Sub:
			case Div:
			case Mul:
			case Mod:
			case Minus:
			case Plus:
				print_aux = do_the_math(son);
				printf("\t%%%d = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([4 x i8]* @.str, i32 0, i32 0), i32 %%%d)\n",variables,variables-1 );
				variables++;
				break;
			/*case Call:
				do_the_math(son);
				printf("\t%%%d = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([4 x i8]* @.str, i32 0, i32 0), i32 %%%d)\n",variables,variables-1 );
				variables++;
				break;*/
			case And:
			case Or:
			case Geq:
			case Leq:
			case Gt:
			case Lt:
			case Eq:
			case Neq:
			case Not:
				print_aux = do_the_boolean_math(son);
				print_boolean(print_aux);
				break;		
			case Length:
				print_aux = do_the_math(son);	
				printf("\t%%%d = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([4 x i8]* @.str, i32 0, i32 0), i32 %s)\n",variables, print_aux );
				variables++;
				break;	
		}
	}
}

void print_boolean(char* print_aux)
{	
	print_bool++;
	if(print_aux[1]<48 || print_aux[1]>57){
		printf("\t%%BOOL%d = load i1* %s\n", print_bool,print_aux);
		
	}
	else{
		printf("\t%%BOOL%d = add i1 0, %s\n", print_bool,print_aux);
	}
	printf("\t%%ifcond%d = icmp eq i1 %%BOOL%d, 1\n",print_bool,print_bool);
	printf("\tbr i1 %%ifcond%d, label %%then%d, label %%else%d\n",print_bool,print_bool,print_bool);
	printf("then%d:\n",print_bool);
	printf("\t%%calltmp%d = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([6 x i8]* @.str3, i32 0, i32 0))\n",print_bool);
	printf("\tbr label %%ifcont%d\n",print_bool);
	printf("else%d:\n",print_bool);
	printf("\t%%calltmp1%d = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([7 x i8]* @.str2, i32 0, i32 0))\n",print_bool);
	printf("\tbr label %%ifcont%d\n",print_bool);
	printf("ifcont%d:\n\n",print_bool);
	//printf("\t%%iftmp%d = phi i32 [ %%calltmp%d, %%then ], [ %%calltmp1%d, %%else ]\n",print_bool,print_bool,print_bool);
	//printf("\tret i32 %%iftmp\n");
}

char* do_the_boolean_math(program_tree*node)
{
	char *aux1,*aux2;
	char *buffer = (char*)malloc(sizeof(char)*10);
	VNODE* search;
	long int li;
	if (node!=NULL)
	{
		switch(node->disc_d)
		{
			case BoolLit:
				if(strcmp(node->val,"false")==0)
					return "0";
				else
					return "1";
				break;
			case IntLit:
				if((node->val)[0]==48 && (node->val)[1]==120)
				{
					li = strtol(node->val,NULL,16);
					snprintf(buffer,10,"%ld",li);
					return buffer;
					break;
				}
				else if((node->val)[0]==48 && (node->val)[1]!=120)
				{
					li = strtol(node->val,NULL,8);
					snprintf(buffer,10,"%ld",li);
					return buffer;
					break;
				}
				else
					return node->val;
				break;
			case Id:
				search = search_var(node);
				buffer = generate_variable_for_using(search);
				return buffer;
				break;
			case And:
				aux1 = do_the_boolean_math(node->son);
				aux2 = do_the_boolean_math(node->son->brother);
				printf("\t%%%d = and i1 %s, %s\n", variables,aux1,aux2);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return buffer;
				break;
			case Or:
				aux1 = do_the_boolean_math(node->son);
				aux2 = do_the_boolean_math(node->son->brother);
				printf("\t%%%d = or i32 %s, %s\n", variables,aux1,aux2);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return buffer;
				break;
			case Geq:
				aux1 = do_the_boolean_math(node->son);
				aux2 = do_the_boolean_math(node->son->brother);
				printf("\t%%%d = icmp sge i32 %s, %s\n", variables,aux1,aux2);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return buffer;
				break;
			case Leq:
				aux1 = do_the_boolean_math(node->son);
				aux2 = do_the_boolean_math(node->son->brother);
				printf("\t%%%d = icmp sle i32 %s, %s\n", variables,aux1,aux2);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return buffer;
				break;
			case Gt:
				aux1 = do_the_boolean_math(node->son);
				aux2 = do_the_boolean_math(node->son->brother);
				printf("\t%%%d = icmp sgt i32 %s, %s\n", variables,aux1,aux2);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return buffer;
				break;
			case Lt:
				aux1 = do_the_boolean_math(node->son);
				aux2 = do_the_boolean_math(node->son->brother);
				printf("\t%%%d = icmp slt i32 %s, %s\n", variables,aux1,aux2);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return buffer;
				break;
			case Eq:
				aux1 = do_the_boolean_math(node->son);
				aux2 = do_the_boolean_math(node->son->brother);
				printf("\t%%%d = icmp eq i32 %s, %s\n", variables,aux1,aux2);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return buffer;
				break;
			case Neq:
				aux1 = do_the_boolean_math(node->son);
				aux2 = do_the_boolean_math(node->son->brother);
				printf("\t%%%d = icmp ne i32 %s, %s\n", variables,aux1,aux2);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return buffer;
				break;
			case Not:
				aux1 = do_the_boolean_math(node->son);
				printf("\t%%%d = icmp ne i1 %s, 0\n",variables,aux1);
				variables++;
				printf("\t%%%d = xor i1 %%%d, 1\n", variables,variables-1);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return buffer;
				break;
			case Add:
				aux1 = do_the_math(node->son);
				aux2 = do_the_math(node->son->brother);
				printf("\t%%%d = add nsw i32 %s, %s\n", variables,aux1,aux2);
				free(aux1);
				free(aux2);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return  buffer;
				break;
			case Sub:
				aux1 = do_the_math(node->son);
				aux2 = do_the_math(node->son->brother);
				printf("\t%%%d = sub nsw i32 %s, %s\n", variables,aux1,aux2);
				free(aux1);
				free(aux2);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return  buffer;
				break;
			case Mul:
				aux1 = do_the_math(node->son);
				aux2 = do_the_math(node->son->brother);
				printf("\t%%%d = mul nsw i32 %s, %s\n", variables,aux1,aux2);
				free(aux1);
				free(aux2);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return  buffer;
				break;
			case Div:
				aux1 = do_the_math(node->son);
				aux2 = do_the_math(node->son->brother);
				printf("\t%%%d = sdiv i32 %s, %s\n", variables,aux1,aux2);
				free(aux1);
				free(aux2);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return  buffer;
				break;
			case Mod:
				aux1 = do_the_math(node->son);
				aux2 = do_the_math(node->son->brother);
				printf("\t%%%d = srem i32 %s, %s\n", variables,aux1,aux2);
				free(aux1);
				free(aux2);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return  buffer;
				break;
			/*case Call:
				for(tmp=node->son->brother ; tmp ; tmp=tmp->brother)
				{
					do_the_math(tmp);
				}
				printf("\t%%%d = call i32 @%s(", variables,node->son->val);
				for(tmp=node->son->brother ; tmp ; tmp=tmp->brother)
				{
					if(countador>0)
						printf(", ");
					aux1 = do_the_math(tmp);
					type_args = check_type(tmp,method_name);

					printf("%s %s", translate_types_to_string(type_args),aux1);
					countador++;

				}
				printf(")\n");
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return buffer;
				break;*/
			case Minus:
				aux1 = do_the_math(node->son);
				printf("\t%%%d = sub nsw i32 0, %s\n",variables,aux1);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return buffer;
				break;
			case Plus:
				aux1 = do_the_math(node->son);
				printf("\t%%%d = add nsw i32 0, %s\n",variables,aux1);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return buffer;
				break;
			case Length:
				if(strcmp(node->son->val,"args")==0)
				{
					snprintf(buffer,10,"%%%s","argc");
					return buffer;
				}
				else{
				aux1 = do_the_math(node->son);
				snprintf (buffer, 10, "%%%d", variables );
				return buffer;
				}
				break;
		}
	}

}

char* do_the_math(program_tree*node)
{
	char *aux1,*aux2;
	char *buffer = (char*)malloc(sizeof(char)*10);
	VNODE* search;
	char *global;
	program_tree*tmp;int countador = 0;
	disc_expression type_args;
	char*typee;
	long int li;

	if (node!=NULL)
	{
		switch(node->disc_d)
		{
			case IntLit: 
				if((node->val)[0]==48 && (node->val)[1]==120)
				{
					li = strtol(node->val,NULL,16);
					snprintf(buffer,10,"%ld",li);
					return buffer;
					break;
				}
				else if((node->val)[0]==48 && (node->val)[1]!=120)
				{
					li = strtol(node->val,NULL,8);
					snprintf(buffer,10,"%ld",li);
					return buffer;
					break;
				}
				else{
					return node->val;
					break;
				}
			case Id:
				search = search_var(node);
				buffer = generate_variable_for_using(search);

				return buffer;
				break;
			case Add:
				aux1 = do_the_math(node->son);
				aux2 = do_the_math(node->son->brother);
				printf("\t%%%d = add nsw i32 %s, %s\n", variables,aux1,aux2);
				free(aux1);
				free(aux2);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return  buffer;
				break;
			case Sub:
				aux1 = do_the_math(node->son);
				aux2 = do_the_math(node->son->brother);
				printf("\t%%%d = sub nsw i32 %s, %s\n", variables,aux1,aux2);
				free(aux1);
				free(aux2);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return  buffer;
				break;
			case Mul:
				aux1 = do_the_math(node->son);
				aux2 = do_the_math(node->son->brother);
				printf("\t%%%d = mul nsw i32 %s, %s\n", variables,aux1,aux2);
				free(aux1);
				free(aux2);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return  buffer;
				break;
			case Div:
				aux1 = do_the_math(node->son);
				aux2 = do_the_math(node->son->brother);
				printf("\t%%%d = sdiv i32 %s, %s\n", variables,aux1,aux2);
				free(aux1);
				free(aux2);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return  buffer;
				break;
			case Mod:
				aux1 = do_the_math(node->son);
				aux2 = do_the_math(node->son->brother);
				printf("\t%%%d = srem i32 %s, %s\n", variables,aux1,aux2);
				free(aux1);
				free(aux2);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return  buffer;
				break;
			/*case Call:
				for(tmp=node->son->brother ; tmp ; tmp=tmp->brother)
				{
					do_the_math(tmp);
				}
				printf("\t%%%d = call i32 @%s(", variables,node->son->val);
				for(tmp=node->son->brother ; tmp ; tmp=tmp->brother)
				{
					if(countador>0)
						printf(", ");
					aux1 = do_the_math(tmp);
					type_args = check_type(tmp,method_name);

					printf("%s %s", translate_types_to_string(type_args),aux1);
					countador++;

				}
				printf(")\n");
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return buffer;
				break;*/
			case Minus:
				aux1 = do_the_math(node->son);
				printf("\t%%%d = sub nsw i32 0, %s\n",variables,aux1);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return buffer;
				break;
			case Plus:
				aux1 = do_the_math(node->son);
				printf("\t%%%d = add nsw i32 0, %s\n",variables,aux1);
				snprintf (buffer, 10, "%%%d", variables );
				variables++;
				return buffer;
				break;
			case Length:
				if(strcmp(node->son->val,"args")==0)
				{
					snprintf(buffer,10,"%%%s","argc");
					return buffer;
				}
				else{
				aux1 = do_the_math(node->son);
				snprintf (buffer, 10, "%%%d", variables );
				return buffer;
				}
				break;


		}
	
	}
}

/*disc_expression check_this_type(program_tree *node)
{
	VNODE*var_aux;
	if(node != NULL)
	{
		switch(node->disc_d)
		{
			case IntLit: return Int;break;
			case Id:

		}
	}
}*/

void generate_methodparams(program_tree *methodparams_node)
{

	program_tree* paramdec_node;
	program_tree* type_node;
	program_tree* id_node;
	VNODE*aux,*tmp;

	int counter=0;

	if(methodparams_node!=NULL)
	{
		for(paramdec_node=methodparams_node->son; paramdec_node; paramdec_node=paramdec_node->brother)
		{
			if(counter>0)
				printf(", ");

			type_node = paramdec_node->son;
			id_node = type_node->brother;

			switch(type_node->disc_d)
			{
				case StringArray:printf("i32 %%argc, i8** %%argv");break;
				default:printf("%s %%%s",translate_types_to_string(type_node->disc_d), id_node->val);break;
			}
			counter++;

			
		}
	}

		printf(") nounwind {\n");

	if(methodparams_node!=NULL)
	{

		for(paramdec_node=methodparams_node->son; paramdec_node; paramdec_node=paramdec_node->brother)
		{

			type_node = paramdec_node->son;
			id_node = type_node->brother;

			switch(type_node->disc_d)
			{
				case Int:printf("\t%%%d = alloca i32\n\tstore i32 %%%s, i32* %%%d\n", variables,id_node->val,variables);break;
				case IntArray:printf("\t%%%d = alloca i32*\n\tstore i32* %%%s, i32** %%%d", variables,id_node->val,variables);break;
				case Bool:printf("\t%%%d = alloca i1\n\tstore i1 %%%s, i1* %%%d\n", variables,id_node->val,variables);break;
				case BoolArray:printf("\t%%%d = alloca i1*\n\tstore i1* %%%s, i1** %%%d", variables,id_node->val,variables);break;
				case StringArray:
					printf("\t%%%d = alloca i32\n\tstore i32 %%argc, i32* %%%d\n",variables,variables);
					variables++;
					printf("\t%%%d = alloca i8**\n\tstore i8** %%argv, i8*** %%%d\n",variables,variables);
					break;
			}
			if(type_node->disc_d!=StringArray)
			{
				aux=(VNODE*) malloc(sizeof(VNODE));
				aux->type = type_node->disc_d;
				aux->method_name = method_name;
				aux->is_global = 0;
				aux->var_name = id_node->val;
				aux->numReg = variables;
				if(vars==NULL)
				vars = aux;
				else
				{
					tmp=vars;
					while(tmp->next!=NULL)
						tmp=tmp->next;
					tmp->next = aux;
				}
				variables++;
			}
			else
			{
				aux=(VNODE*) malloc(sizeof(VNODE));
				aux->type = type_node->disc_d;
				aux->method_name = method_name;
				aux->is_global = 0;
				aux->var_name = "argc";
				aux->numReg = 1;
				if(vars==NULL)
				vars = aux;
				else
				{
					tmp=vars;
					while(tmp->next!=NULL)
						tmp=tmp->next;
					tmp->next = aux;
				}

				aux=(VNODE*) malloc(sizeof(VNODE));
				aux->type = type_node->disc_d;
				aux->method_name = method_name;
				aux->is_global = 0;
				aux->var_name = "argv";
				aux->numReg = 2;
				if(vars==NULL)
				vars = aux;
				else
				{
					tmp=vars;
					while(tmp->next!=NULL)
						tmp=tmp->next;
					tmp->next = aux;
				}
				variables++;
			}


		
		}
	}
}

VNODE* search_var(program_tree * id_node)
{
	VNODE*tmp;
	if(id_node != NULL)
	{
		for(tmp = vars ; tmp ; tmp=tmp->next)
		{
			if(strcmp(tmp->var_name,id_node->val)==0 && strcmp(tmp->method_name,method_name)==0)
			{
				return tmp;
			}
		}

		for(tmp = vars ; tmp ; tmp=tmp->next)
		{
			if(strcmp(tmp->var_name,id_node->val)==0)
			{
				return tmp;
			}
		}
	}
}
